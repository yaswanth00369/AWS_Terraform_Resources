#!/bin/bash

yum update -y
hostnamectl set-hostname jenkins

yum install java-1.8.0* -y
yum install git -y

wget -O /etc/yum.repos.d/jenkins.repo https://pkg.jenkins.io/redhat-stable/jenkins.repo
rpm --import https://pkg.jenkins.io/redhat-stable/jenkins.io.key
amazon-linux-extras install epel -y
yum install jenkins -y
systemctl start jenkins
systemctl enable jenkins

yum install python-pip -y
pip install --upgrade pip
pip install boto
pip install boto3

yum install ansible -y