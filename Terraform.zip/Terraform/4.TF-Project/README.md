# Webserver Apache HTTP Service Access

Open Broeser and search the Route 53 Record Name {

    For Classic Load Balancer {
        http://terraform.elb.yaswanth.tk
    }
    For Application Load Balancer {
        http://terraform.alb.yaswanth.tk
    }    
}

# Webserver WordPress-App Server Access & Connect to RDS DB

Open Broeser and search the Route 53 Record Name with /wordpress {

    For Classic Load Balancer {
        http://terraform.elb.yaswanth.tk/wordpress
    }
    For Application Load Balancer {
        http://terraform.alb.yaswanth.tk/wordpress
    }    
}