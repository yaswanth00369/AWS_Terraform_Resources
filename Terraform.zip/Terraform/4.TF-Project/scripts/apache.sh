#!/bin/bash
yum update -y
yum install httpd php php-mysql -y
amazon-linux-extras install lamp-mariadb10.2-php7.2 php7.2 -y
cd /var/www/html
wget https://wordpress.org/wordpress-5.1.1.tar.gz
tar -xvzf wordpress-5.1.1.tar.gz
rm -rf wordpress-5.1.1.tar.gz
chmod -R 755 wordpress/wp-content/
chown -R apache:apache wordpress/wp-content/

EC2_AVAIL_ZONE=$(curl -s http://169.254.169.254/latest/meta-data/placement/availability-zone)
echo "<h1>Hello World from $(hostname -f) in AZ $EC2_AVAIL_ZONE </h1>" > /var/www/html/index.html

systemctl start httpd.service
systemctl enable httpd.service